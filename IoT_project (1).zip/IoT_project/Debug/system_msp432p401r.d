# FIXED

system_msp432p401r.obj: ../system_msp432p401r.c
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp432p401r.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp_compatibility.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp432p401r_classic.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/core_cm4.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h
system_msp432p401r.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/system_msp432p401r.h

../system_msp432p401r.c:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp432p401r.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp_compatibility.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/msp432p401r_classic.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/core_cm4.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/system_msp432p401r.h:

