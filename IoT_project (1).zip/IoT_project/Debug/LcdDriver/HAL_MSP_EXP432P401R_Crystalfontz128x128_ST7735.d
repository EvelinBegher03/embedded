# FIXED

LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: ../LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.c
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: ../LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/driverlib.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/adc14.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp432p401r.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp_compatibility.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp432p401r_classic.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/core_cm4.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/system_msp432p401r.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/aes256.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/comp_e.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/cpu.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/crc32.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/cs.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/dma.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/interrupt.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/eusci.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/fpu.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/gpio.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/i2c.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/mpu.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/pcm.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/pmap.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/pss.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/ref_a.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/reset.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/rom.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/rom_map.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/rtc_c.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/spi.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/systick.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/timer32.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/timer_a.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/uart.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/wdt_a.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/sysctl.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/flash.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/grlib/grlib.h
LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.obj: /Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/assert.h

../LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.c:

../LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdint.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_ti_config.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/linkage.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/_stdint40.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/stdint.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/cdefs.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_types.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_types.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/machine/_stdint.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/sys/_stdint.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/driverlib.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/adc14.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/stdbool.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp432p401r.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp_compatibility.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/msp432p401r_classic.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/core_cm4.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_compiler.h:

/Applications/ti/ccs1280/ccs/ccs_base/arm/include/CMSIS/cmsis_ccs.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/inc/system_msp432p401r.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/aes256.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/comp_e.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/cpu.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/crc32.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/cs.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/dma.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/interrupt.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/eusci.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/fpu.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/gpio.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/i2c.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/mpu.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/pcm.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/pmap.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/pss.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/ref_a.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/reset.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/rom.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/rom_map.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/rtc_c.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/spi.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/systick.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/timer32.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/timer_a.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/uart.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/wdt_a.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/sysctl.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/devices/msp432p4xx/driverlib/flash.h:

/Users/nicolobelle/ti/simplelink_msp432p4_sdk_3_40_01_02/source/ti/grlib/grlib.h:

/Applications/ti/ccs1280/ccs/tools/compiler/ti-cgt-arm_20.2.7.LTS/include/assert.h:

